tester for OS HW3 - part 2
last update: 3.1.21

please notice this tester is not 100% completed. passing (or failing) all the tests does not mean your code is ready for submission.
all this tester does is to run different boards with your code and compare the input with what we assume should be the expected output.
especially, this tester does not test correctness of mutex using, multi threading, structure of code, tile/gen hist or that it pass makefile given by the Segel

in order to run the tester: * 
put all your code for part 2 (Game, Thread and any other code you wrote) inside "put_all_your_code_here" (no need to put main.cpp there)
(you may need to change the directories in your #include command inside Game and Thread because the compile command assume all files are in the same directory)
then open terminal from the directory "tester-3.1.21" and type "python run.py"

* note that you can also compile with all the Segel's makefile flags: in run.py, replace line 8 line 7 (the line with the '#')

good luck